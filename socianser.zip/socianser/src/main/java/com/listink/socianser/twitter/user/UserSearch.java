package com.listink.socianser.twitter.user;

import twitter4j.*;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by mersalin on 6/9/2016.
 */
public class UserSearch {
    private String query;

    public UserSearch(String query) {
        this.query = query;
    }

    public List<User> searchUsers() {
        try {
            Twitter twitter = new TwitterFactory().getSingleton();
            int page = 1;
            ResponseList<User> users;
            List<User> twitterUsers = new ArrayList<>();
            do {
                users = twitter.searchUsers(query, page);
                for (User user : users) {
                    if (!user.isProtected()) {
                        System.out.println("@" + user.getScreenName());
                        twitterUsers.add(user);
                    } else {
                        System.out.println("Protected User: @" + user.getScreenName());
                    }
                }
                page++;
            } while (users.size() != 0 && page < 3);
            return twitterUsers;
        } catch (TwitterException te) {
            te.printStackTrace();
            System.out.println("Failed to search users: " + te.getMessage());
        }
        return new ArrayList<User>(0);
    }
}
