package com.listink.socianser.analyse;

import com.listink.socianser.Configuration;
import com.listink.socianser.paper.author.Author;
import com.listink.socianser.twitter.user.UserSearch;
import twitter4j.User;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by mersalin on 6/9/2016.
 */
public class TwitterAnalyzer implements Analyze{
    private Configuration config;

    public TwitterAnalyzer(Configuration config) {
        this.config = config;
    }

    @Override
    public Author analyzeAuthor() {
        UserSearch userSearch = new UserSearch(generateQuery());
        return null;
    }

    private Author extractAuthorData(List<User> users) {

        return null;
    }

    private User findUserMatch(List<User> users) {
        for(User user : users) {

        }
        return null;
    }

    private String generateQuery() {
        return config.getName();
    }
}
