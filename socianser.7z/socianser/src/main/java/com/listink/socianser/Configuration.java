package com.listink.socianser;

/**
 * Created by mastho on 6/9/2016.
 */
public class Configuration {
    private String name;
    private String source;
    private String sourceURL;

    public Configuration(String name, String source, String sourceURL) {
        this.name = name;
        this.source = source;
        this.sourceURL = sourceURL;
    }

    public String getName() {
        return name;
    }

    public String getSource() {
        return source;
    }

    public String getSourceURL() {
        return sourceURL;
    }

    public Configuration setName(String name) {
        this.name = name;
        return this;
    }

    public Configuration setSource(String source) {
        this.source = source;
        return this;
    }

    public Configuration setSourceURL(String sourceURL) {
        this.sourceURL = sourceURL;
        return this;
    }

    public Configuration build() {
        return new Configuration(name,source,sourceURL);
    }
}
