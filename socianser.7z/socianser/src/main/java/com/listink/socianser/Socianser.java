package com.listink.socianser;

import com.listink.socianser.analyse.Analyze;
import com.listink.socianser.analyse.TwitterAnalyzer;

/**
 * Created by mersalin on 6/9/2016.
 */
public class Socianser {
    public void socianzeTwitter() {

    }
}
