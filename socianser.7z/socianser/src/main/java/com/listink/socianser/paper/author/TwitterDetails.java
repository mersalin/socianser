package com.listink.socianser.paper.author;

import twitter4j.Status;
import twitter4j.User;

import java.util.List;

/**
 * Created by mersalin on 6/9/2016.
 */
public class TwitterDetails {
    private String name;
    private String location;
    private String language;
    private String description;
    private String createdAt;
    private String website;
    private long friendsCount;
    private long followersCount;
    private String descriptionURLEntities;
    private long statusesCount;
    private String timezone;
    private long favouritesCount;
    private String profileImageURL;
    private String miniProfileImageURL;
    private List<Status> latestTweets;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getWebsite() {
        return website;
    }

    public void setWebsite(String website) {
        this.website = website;
    }

    public long getFriendsCount() {
        return friendsCount;
    }

    public void setFriendsCount(long friendsCount) {
        this.friendsCount = friendsCount;
    }

    public long getFollowersCount() {
        return followersCount;
    }

    public void setFollowersCount(long followersCount) {
        this.followersCount = followersCount;
    }

    public String getDescriptionURLEntities() {
        return descriptionURLEntities;
    }

    public void setDescriptionURLEntities(String descriptionURLEntities) {
        this.descriptionURLEntities = descriptionURLEntities;
    }

    public long getStatusesCount() {
        return statusesCount;
    }

    public void setStatusesCount(long statusesCount) {
        this.statusesCount = statusesCount;
    }

    public String getTimezone() {
        return timezone;
    }

    public void setTimezone(String timezone) {
        this.timezone = timezone;
    }

    public long getFavouritesCount() {
        return favouritesCount;
    }

    public void setFavouritesCount(long favouritesCount) {
        this.favouritesCount = favouritesCount;
    }

    public String getProfileImageURL() {
        return profileImageURL;
    }

    public void setProfileImageURL(String profileImageURL) {
        this.profileImageURL = profileImageURL;
    }

    public String getMiniProfileImageURL() {
        return miniProfileImageURL;
    }

    public void setMiniProfileImageURL(String miniProfileImageURL) {
        this.miniProfileImageURL = miniProfileImageURL;
    }

    public List<Status> getLatestTweets() {
        return latestTweets;
    }

    public void setLatestTweets(List<Status> latestTweets) {
        this.latestTweets = latestTweets;
    }

    @Override
    public String toString() {
        return "TwitterDetails{" +
                "name='" + name + '\'' +
                ", location='" + location + '\'' +
                ", language='" + language + '\'' +
                ", description='" + description + '\'' +
                ", createdAt='" + createdAt + '\'' +
                ", website='" + website + '\'' +
                ", friendsCount=" + friendsCount +
                ", followersCount=" + followersCount +
                ", descriptionURLEntities='" + descriptionURLEntities + '\'' +
                ", statusesCount=" + statusesCount +
                ", timezone='" + timezone + '\'' +
                ", favouritesCount=" + favouritesCount +
                ", profileImageURL='" + profileImageURL + '\'' +
                ", miniProfileImageURL='" + miniProfileImageURL + '\'' +
                ", latestTweets=" + latestTweets +
                '}';
    }
}
