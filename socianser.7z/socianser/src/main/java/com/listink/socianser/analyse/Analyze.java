package com.listink.socianser.analyse;

import com.listink.socianser.paper.author.Author;

/**
 * Created by mersalin on 6/9/2016.
 */
public interface Analyze {
    public Author analyzeAuthor();
}
