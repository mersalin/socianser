package com.listink.socianser.paper.author;

/**
 * Created by mastho on 6/9/2016.
 */
public class Author {
    private String worktitle;
}
